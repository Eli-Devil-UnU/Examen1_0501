import 'package:flutter/material.dart';

void main() {
  runApp(const TabacoApp());
}

class TabacoApp extends StatelessWidget {
  const TabacoApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Jose Elias Melendez Portillo 6J 0501',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: const TabacoHomePage(),
    );
  }
}

class TabacoHomePage extends StatelessWidget {
  const TabacoHomePage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Jose Elias Melendez Portillo 6J 0501'),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16.0),
        children: const <Widget>[
          TabacoCard(
            title: 'Cigarros',
            description: 'Explora nuestra selección de cigarros premium.',
            imageURL:
                'https://raw.githubusercontent.com/Eli-Devil-UnU/Examen1_0501/main/examen1/cigarros.jpg',
          ),
          TabacoCard(
            title: 'Pipas',
            description: 'Descubre nuestras pipas de alta calidad.',
            imageURL:
                'https://raw.githubusercontent.com/Eli-Devil-UnU/Examen1_0501/main/examen1/pipas.jpg',
          ),
          TabacoCard(
            title: 'Accesorios',
            description: 'Encuentra los mejores accesorios para fumar.',
            imageURL:
                'https://raw.githubusercontent.com/Eli-Devil-UnU/Examen1_0501/main/examen1/accesorios.jpg',
          ),
        ],
      ),
    );
  }
}

class TabacoCard extends StatelessWidget {
  final String title;
  final String description;
  final String imageURL;

  const TabacoCard({
    Key? key,
    required this.title,
    required this.description,
    required this.imageURL,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          AspectRatio(
            aspectRatio: 16 / 9,
            child: Image.network(
              imageURL,
              fit: BoxFit.cover,
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(
                  title,
                  style: const TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 20.0,
                  ),
                ),
                const SizedBox(height: 8.0),
                Text(
                  description,
                  style: const TextStyle(fontSize: 16.0),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
