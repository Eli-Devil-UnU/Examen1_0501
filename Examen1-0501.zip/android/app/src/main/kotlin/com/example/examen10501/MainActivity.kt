package com.example.examen10501

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
